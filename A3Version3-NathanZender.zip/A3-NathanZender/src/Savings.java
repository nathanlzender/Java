/**
 * Assignment 3: This is the savings account class and calculates compound interest
 * Issues: N/A
 * @author NathanZender
 * @version 1.0
 */

public class Savings 
{
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable declaration
				
	private float accountBalanceInstance;
	private int accountNumberInstance;
	private final float INTEREST_RATE = 1.015f;
			
	//--------------------------------------------------------------------------------------------------------------
	//Constructor
	
	public Savings()
	{
		accountBalanceInstance = 0;
		accountNumberInstance = 0;
	}
	
	//--------------------------------------------------------------------------------------------------------------
	//Setters
			 
	public void setAccountBalanceInstance (float n) 
	{
		accountBalanceInstance = n;
	}
		
	public void setAccountNumberInstance (int n) 
	{
		accountNumberInstance = n;
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable getters
		
	public float getAccountBalanceInstance () 
	{
		return accountBalanceInstance;
	}
		
	public int getAccountNumberInstance () 
	{
		return accountNumberInstance;
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Methods
		
	public float calculateInterest(float interestPeriodInstance)
	{
		float interest = 0;
		interest = (float) (Math.pow(INTEREST_RATE, interestPeriodInstance) * getAccountBalanceInstance()) - getAccountBalanceInstance() ;
		return interest;
	}
		
	public void displayAccount(float interestPeriodInstance)
	{
		System.out.println("Savings Account Number: " + getAccountNumberInstance ());
		System.out.println("Savings Balance: " + getAccountBalanceInstance () + "$");
		System.out.println("Compound Interest incurred over " + interestPeriodInstance + " years: " + String.format("%.2f",calculateInterest(interestPeriodInstance)) + "$");
		System.out.println("Savings Account Balance after Interest: " + String.format("%.2f",(calculateInterest(interestPeriodInstance) + getAccountBalanceInstance ())) + "$");
		System.out.println("");
		System.out.println("====================");
	}
		
				
	
}
		 

