import java.util.Scanner;

/**
 * Assignment 3: This class drives the program, asking for initial input values balance, interest rate, and duration 
 * Issues: N/A
 * @author NathanZender
 * @version 1.0
 */

public class Bank {
	
	public static void main(String[] args) 
	{
		int firstChoice = 4;
		
		Scanner input = new Scanner (System.in);
		while (firstChoice != 3) 
		{
			System.out.println("Enter 1 for Savings, 2 for Checking, or 3 to quit: ");
			firstChoice = input.nextInt();
		
		
			if (firstChoice == 1) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// initializing object
			
				Savings savingsObject = new Savings();
				
				//--------------------------------------------------------------------------------------------------------------
				// initializing variables
				float interestPeriod;
				
				//--------------------------------------------------------------------------------------------------------------
				// Asking input
				
			
				System.out.println("Please enter the Savings account number: ");
				savingsObject.setAccountNumberInstance(input.nextInt());
				 
				System.out.println("Please enter the Savings account balance: ");
				savingsObject.setAccountBalanceInstance(input.nextFloat());
				 
				System.out.println("Enter the interest period in years: ");
				interestPeriod = input.nextFloat();
				 
				System.out.println("====================");
				
				savingsObject.displayAccount(interestPeriod);
			}
		
			else if (firstChoice == 2) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// initializing variables
			
				float interestPeriod = 0;
			
				//--------------------------------------------------------------------------------------------------------------
				// initializing object
			
				Checking calculatorCheckings = new Checking();
			
				//--------------------------------------------------------------------------------------------------------------
				// Asking input
			
				System.out.println("Please enter the Checking account number: ");
				calculatorCheckings.setAccountNumberInstance(input.nextInt());
			 
				System.out.println("Please enter the Checking account balance: ");
				calculatorCheckings.setAccountBalanceInstance(input.nextFloat());
			 
				System.out.println("Enter the interest period in years: ");
				interestPeriod = input.nextFloat();
			 
				System.out.println("====================");
			
				calculatorCheckings.displayAccount(interestPeriod);
			}
		
			else if(firstChoice == 3) 
			{
				System.out.println("Exiting program");
				input.close();
				System.exit(0);
			}
		
			else 
			{
				System.out.println("You've entered an incorrect number, enter another one");
				System.out.println("");
			}
		
		}


	}

}
