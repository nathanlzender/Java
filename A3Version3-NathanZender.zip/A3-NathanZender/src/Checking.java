/**
 * Assignment 3: This is the checking account class and calculates simple interest
 * Issues: N/A
 * @author NathanZender
 * @version 1.0
 */

public class Checking
{
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable declaration
			
	private float accountBalanceInstance;
	private int accountNumberInstance;
	private final float INTEREST_RATE = .005f;
	
	//--------------------------------------------------------------------------------------------------------------
	//Constructor
		
	public Checking()
	{
		accountBalanceInstance = 0;
		accountNumberInstance = 0;
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Setters
		 
	public void setAccountBalanceInstance (float n) 
	{
		accountBalanceInstance = n;
	}
		
	public void setAccountNumberInstance (int n) 
	{
		accountNumberInstance = n;
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable getters
		
	public float getAccountBalanceInstance () 
	{
		return accountBalanceInstance;
	}
		
	public int getAccountNumberInstance () 
	{
		return accountNumberInstance;
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Methods
		
	public float calculateInterest(float interestPeriodInstance)
	{
		float interest = 0;
		interest = (float) (INTEREST_RATE * interestPeriodInstance *accountBalanceInstance) ;
		return interest;
	}
		
	public void displayAccount(float interestPeriodInstance)
	{
		System.out.println("Checking Account Number: " + getAccountNumberInstance ());
		System.out.println("Checking Balance: " + getAccountBalanceInstance () + "$");
		System.out.println("Simple Interest incurred over " + interestPeriodInstance + " years: " + String.format("%.2f",calculateInterest( interestPeriodInstance)) + "$");
		System.out.println("Checking Account Balance after Interest: " + String.format("%.2f",(calculateInterest(interestPeriodInstance) + getAccountBalanceInstance ())) + "$");
		System.out.println("");
		System.out.println("====================");
	}
		
}
		 

