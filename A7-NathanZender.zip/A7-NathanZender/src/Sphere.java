
public class Sphere extends ThreeDShape
{
	protected double radius;
	private String shape;

	public Sphere(double radius)
	{
		this.radius = radius;
		super.setVolume((4d / 3d) * (Math.PI * Math.pow(radius, 3d)));
		super.setArea(4d * Math.PI * Math.pow(radius, 2d));
		shape = "sphere";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getArea()
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}

}
