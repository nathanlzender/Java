
public class Square extends TwoDShape

{
	protected double side;
	private String shape;

	public Square(double side)
	{
		this.side = side;
		super.setPerimeter(4d * side);
		super.setArea(Math.pow(side,2d));
		shape = "square";
	}

	public String getShape()
	{
		return shape;
	}
	
	public double getPerimeter()
	{
		return perimeter;
	}
	
	public double getArea()
	{
		return area;
	}
	
}

