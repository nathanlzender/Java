
public class Triangle extends TwoDShape
{
	protected double sideHeight;
	protected double base;
	protected double hypotenuse;
	private String shape;

	public Triangle(double sideHeight, double base, double hypotenuse)
	{
		this.sideHeight = sideHeight;
		this.base = base;
		this.hypotenuse = hypotenuse;
		super.setPerimeter(sideHeight + base + hypotenuse);
		super.setArea(.5d * (base * sideHeight) );
		shape = "triangle";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getPerimeter()
	{
		return perimeter;
	}
	
	public double getArea()
	{
		return area;
	}
	
} 


