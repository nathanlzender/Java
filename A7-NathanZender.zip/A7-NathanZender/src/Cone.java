
public class Cone extends ThreeDShape
{
	protected double radius;
	protected double height;
	private String shape;

	public Cone(double radius, double height)
	{
		this.radius = radius;
		this.radius = height;
		super.setVolume((1d / 3d) * (Math.PI * Math.pow(radius, 2d) * height));
		super.setArea((Math.PI * Math.pow(radius, 2d) + (Math.PI * radius * Math.sqrt(Math.pow(radius, 2d) + Math.pow(height, 2d)))));
		shape = "cone";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getArea()
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}

}