
public class Rectangle extends TwoDShape
{
	protected double width;
	protected double length;
	private String shape;

	public Rectangle(double width, double length)
	{
		this.width = width;
		this.length = length;
		super.setPerimeter(2d * (length + width));
		super.setArea(width * length);
		shape = "rectangle";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getPerimeter()
	{
		return perimeter;
	}
	
	public double getArea()
	{
		return area;
	}
	
}
