/**
 * Assignment 1: The bank class...
 * Issues: N/A
 * @author NathanZender
 * @version 1.0
 */



import java.util.Scanner;
public class Bank 
{

	public static void main(String[] args)
	
	{
		/* initializing variables
		 */
		Scanner input = new Scanner (System.in);
		double balanceCheckings = 0;
		double interestrateCheckings = 0;
		int yeardurationCheckings = 0;
		double interestCheckings = 0;
		double endYearbalanceCheckings = 0;
		
		double balanceSavings = 0;
		double interestrateSavings = 0;
		int yeardurationSavings = 0;
		double interestSavings = 0;
		double endYearbalanceSavings = 0;
		
		/* Asking input for checking's account: Beginning balance, interest rate, and year amount
		 */
		
		System.out.println("What is the starting balance for the checking account?");
		balanceCheckings = input.nextInt();
		
		System.out.println("What is the interest rate(in percentage)?");
		interestrateCheckings = input.nextInt();
		interestrateCheckings = interestrateCheckings * .01;

		System.out.println("How many years do you want to calculate for?");
		yeardurationCheckings = input.nextInt();
		
		/* Calculating the total interest and adding that to the beginning balance for the checking's account
		 */
		
		interestCheckings = ((balanceCheckings * interestrateCheckings)) * yeardurationCheckings;
		endYearbalanceCheckings = balanceCheckings + interestCheckings;
		
		
		/* Asking input for saving's account: Beginning balance, interest rate, and year amount
		 */
		
		System.out.println("What is the starting balance for the saving account?");
		balanceSavings = input.nextInt();
		
		System.out.println("What is the interest rate(in percentage)?");
		interestrateSavings = input.nextInt();
		interestrateSavings = interestrateSavings * .01;

		System.out.println("How many years do you want to calculate for?");
		yeardurationSavings = input.nextInt();
		
		/* Calculating the total interest and adding that to the beginning balance for the checking's account
		 */
		
		interestSavings = ((balanceSavings * interestrateSavings)) * yeardurationSavings;
		endYearbalanceSavings = balanceSavings + interestSavings;
		
		/* Final bank statement output
		 */
		System.out.println("-------------------------");
		System.out.println("Huntington Bank Statment");
		System.out.println("-------------------------");
		System.out.println("");
		System.out.println("Checkings Acount:"); 
		System.out.println("Beginning Balance: " + balanceCheckings + "$");
		System.out.println("Interest at " + interestrateCheckings + " for " + yeardurationCheckings + " years is: " + interestCheckings + "$");
		System.out.println("The total balance of your checkings account after " + yeardurationCheckings + " years will be " + endYearbalanceCheckings );
		System.out.println("");
		System.out.println("Savings Acount:"); 
		System.out.println("Beginning Balance: " + balanceSavings + "$");
		System.out.println("Interest at " + interestrateSavings + " for " + yeardurationSavings + " years is: " + interestSavings + "$");
		System.out.println("The total balance of your checkings account after " + yeardurationSavings + " years will be " + endYearbalanceSavings);
		
		
		input.close();
		
	}

}
