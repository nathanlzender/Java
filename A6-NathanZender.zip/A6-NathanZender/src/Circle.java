
public class Circle extends TwoDShape

{
	protected double radius;
	private String shape;

	public Circle(double radius)
	{
		this.radius = radius;
		super.setPerimeter(2d * Math.PI * radius);
		super.setArea(Math.PI * (Math.pow(radius,2d)));
		shape = "circle";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getPerimeter()
	{
		return perimeter;
	}
	
	public double getArea()
	{
		return area;
	}
	
}
