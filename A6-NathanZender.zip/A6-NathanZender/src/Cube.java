
public class Cube extends ThreeDShape
{
	protected double edge;
	private String shape;

	public Cube(double edge)
	{
		this.edge = edge;
		super.setVolume(Math.pow(edge, 3d));
		super.setArea(6d * Math.pow(edge, 2d));
		shape = "cube";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getArea()
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}

}