
public class Cylinder extends ThreeDShape
{
	protected double radius;
	protected double height;
	private String shape;

	public Cylinder(double radius, double height)
	{
		this.radius = radius;
		this.radius = height;
		super.setVolume(Math.PI * Math.pow(radius, 2d) * height);
		super.setArea((2d * Math.PI * radius * height) + (2d * Math.PI * Math.pow(radius, 2d)));
		shape = "cylinder";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getArea()
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}

}