
// This is the superclass to all 2d shape classes

public class TwoDShape extends Shape
{
	protected double area;
	protected double perimeter;
	protected String shape;
	
	public void setArea(double area) 
	{
		this.area = area;
	}
	
	public void setPerimeter(double perimeter) 
	{
		this.perimeter = perimeter;
	}
	
	public double getArea() 
	{
		return area;
	}
	
	public double getPerimeter() 
	{
		return perimeter;
	}
	
	public String getShape()
	{
		return shape;
	}
	
	@Override
	public String toString() 
	{		
		String outputArea = "";
		String outputPerimeter = "";
		outputPerimeter = String.format("Perimeter = %.2f", perimeter);
		outputArea = String.format("Area = %.2f", area);
		return outputArea + "\n" + outputPerimeter;
	}
}

