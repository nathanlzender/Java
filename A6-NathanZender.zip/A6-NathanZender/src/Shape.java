import java.util.ArrayList;
import java.util.Scanner;

/**
 * Assignment 6: This class drives the program and is the superclass to the ThreeDShape and TwoDShape super classes
 * Issues: N/A
 * @author Nathan Zender
 * @version 1.0
 */

public class Shape {
	Scanner input = new Scanner (System.in);

	ArrayList<Shape> shapeList = new ArrayList<Shape>();
	public static void main(String[] args) 
	{
		Scanner input = new Scanner (System.in);
		//--------------------------------------------------------------------------------------------------------------
		// initializing variables and objects
		String chosenShape;
		int listChoice = -1;
		Shape shapeObject = new Shape();
		while (listChoice != 6) 
		{
			System.out.println("====================");
			System.out.println("Please choose an option:" + "\n" +  "Enter 1 to enter a new shape" + "\n" + "Enter 2 to display all the shapes currently added" + "\n" +  "Enter 3 to display all the 2d shapes" + "\n" + "Enter 4 to display all the 3d shapes" + "\n" +   "Enter 5 to display all the information of a specific set of shapes" + "\n" + "Enter 6 to exit"); 
			System.out.println("====================");
			listChoice = input.nextInt();
			
			
			if (listChoice == 1) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Option to add new shape
				System.out.println("What shape would you like to add to the collection?");
				System.out.println("2D Choices: circle, square, rectangle, triangle(right-angle only), parallelogram");
				System.out.println("3D Choices: sphere, cylinder, cone, cube, prism, square pyramid");
				chosenShape = input.next();
				chosenShape += input.nextLine();
				chosenShape = chosenShape.toLowerCase();			
				if ((chosenShape.equals("circle")) || (chosenShape.equals("square")) || (chosenShape.equals("rectangle")) || (chosenShape.equals("triangle")) || (chosenShape.equals("parallelogram"))) 
				{
					shapeObject.twoDshape(chosenShape);
				}
				
				else 
				{
					shapeObject.threeDshape(chosenShape);
				}
			}
			
			else if (listChoice == 2) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Option to display all shapes
				for (int x = 0; x < shapeObject.shapeList.size(); x++) 
				{
					System.out.println(shapeObject.shapeList.get(x).getShape() + ": " + x + " has the following dimensions: ");
					System.out.println(shapeObject.shapeList.get(x).toString() + "\n");
				}
			}
			
			else if (listChoice == 3) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Option to display all 2d shapes
				
				for (int x = 0; x < shapeObject.shapeList.size(); x++) 
				{
					if (shapeObject.shapeList.get(x).getShape().equals("circle") || shapeObject.shapeList.get(x).getShape().equals("square") || shapeObject.shapeList.get(x).getShape().equals("rectangle") || shapeObject.shapeList.get(x).getShape().equals("triangle") || shapeObject.shapeList.get(x).getShape().equals("parallelogram"))
					{
					System.out.println(shapeObject.shapeList.get(x).getShape() + ": " + x + " has the following dimensions: ");
					System.out.println(shapeObject.shapeList.get(x).toString() + "\n");
					}
				}
			}
			
			else if (listChoice == 4) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Option to display all 3d shapes
				for (int x = 0; x < shapeObject.shapeList.size(); x++) 
				{
					if (!shapeObject.shapeList.get(x).getShape().equals("circle")  & !shapeObject.shapeList.get(x).getShape().equals("square") & !shapeObject.shapeList.get(x).getShape().equals("rectangle") & !shapeObject.shapeList.get(x).getShape().equals("triangle") & !shapeObject.shapeList.get(x).getShape().equals("parallelogram"))
					{
					System.out.println(shapeObject.shapeList.get(x).getShape() + ": " + x + " has the following dimensions: ");
					System.out.println(shapeObject.shapeList.get(x).toString() + "\n");
					}
				}
			}
			
			else if (listChoice == 5)
			{
				//--------------------------------------------------------------------------------------------------------------
				// Option to display values of one set of shapes
				System.out.println("What set of shapes would you like to display? (Do not include plural 's' letter)");
				chosenShape = input.next();
				chosenShape += input.nextLine();
				for (int x = 0; x < shapeObject.shapeList.size(); x++) 
				{
					if (chosenShape.equals(shapeObject.shapeList.get(x).getShape()))
					{
						System.out.println(shapeObject.shapeList.get(x).getShape() + ": " + x + " has the following dimensions: ");
						System.out.println(shapeObject.shapeList.get(x).toString() + "\n");
					}
					
				}
				
			}
			
			else if (listChoice == 6) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Option to exit program
				System.out.println("");
				System.out.println("Exiting program");
				input.close();
				System.exit(0);
			}
		
		
		}
		
	}
	
	public void twoDshape(String chosenShape) 
	{
		// If this method is selected, it uses the inputed shape to ask for the appropriate measurements for 2d shapes
		if (chosenShape.equals("circle")) 
		{
			double radius;
			System.out.println("Please enter the radius of the circle: ");
			radius = input.nextDouble();			
			Circle circleObject = new Circle(radius);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(circleObject);
			System.out.println("The circle has been added to the list with the following dimensions");
			System.out.println(circleObject.toString());
			
		}
		
		else if (chosenShape.equals("square")) 
		{
			double side;
			System.out.println("Please enter the side length of the square: ");
			side = input.nextDouble();			
			Square squareObject = new Square(side);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new square object and storing the area and perimeter
			shapeList.add(squareObject);
			System.out.println("The square has been added to the list with the following dimensions");
			System.out.println(squareObject.toString());
		}
		
		else if (chosenShape.equals("rectangle")) 
		{
			double width;
			double length;
			System.out.println("Please enter the width of the rectangle: ");
			width = input.nextDouble();
			
			System.out.println("Please enter the length of the rectangle: ");
			length = input.nextDouble();
			Rectangle rectangleObject = new Rectangle(width, length);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new rectangle object and storing the area and perimeter
			shapeList.add(rectangleObject);
			System.out.println("The rectangle has been added to the list with the following dimensions");
			System.out.println(rectangleObject.toString());
		}

		else if (chosenShape.equals("triangle")) 
		{
			double sideHeight;
			double base;
			double hypotenuse;
			
			System.out.println("Please enter the hypotenuse of the triangle: ");
			hypotenuse = input.nextDouble();
			
			System.out.println("Please enter the base of the triangle: ");
			base = input.nextDouble();
			
			System.out.println("Please enter the third side of the triangle (used as height): ");
			sideHeight = input.nextDouble();
			
			Triangle triangleObject = new Triangle(sideHeight,base,hypotenuse);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new triangle object and storing the area and perimeter
			shapeList.add(triangleObject);
			System.out.println("The triangle has been added to the list with the following dimensions");
			System.out.println(triangleObject.toString());
		}

		else if (chosenShape.equals("parallelogram")) 
		{
			double base;
			double height;
			double side;
			
			System.out.println("Please enter the base length of the parallelogram: ");
			base = input.nextDouble();
			
			System.out.println("Please enter the height of the parallelogram: ");
			height = input.nextDouble();
			
			System.out.println("Please enter the length of one side of the parallelogram: ");
			side = input.nextDouble();
			
			Parallelogram parallelogramObject = new Parallelogram(base,height,side);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new parallelogram object and storing the area and perimeter
			shapeList.add(parallelogramObject);
			System.out.println("The parallelogram has been added to the list with the following dimensions");
			System.out.println(parallelogramObject.toString());
		}
		
	}
	
	public void threeDshape(String chosenShape) 
	{
		// If this method is selected, it uses the inputed shape to ask for the appropriate measurements for 2d shapes
		if (chosenShape.equals("sphere")) 
		{
			double radius;
			System.out.println("Please enter the radius of the sphere: ");
			radius = input.nextDouble();			
			Sphere sphereObject = new Sphere(radius);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(sphereObject);
			System.out.println("The sphere has been added to the list with the following dimensions");
			System.out.println(sphereObject.toString());
		}
		
		else if (chosenShape.equals("cylinder")) 
		{
			double radius;
			double height;
			System.out.println("Please enter the radius of the cylinder: ");
			radius = input.nextDouble();
			
			System.out.println("Please enter the height of the cylinder: ");
			height = input.nextDouble();
			
			Cylinder cylinderObject = new Cylinder(radius,height);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(cylinderObject);
			System.out.println("The cylinder has been added to the list with the following dimensions");
			System.out.println(cylinderObject.toString());
		}
		
		else if (chosenShape.equals("cone")) 
		{
			double radius;
			double height;
			System.out.println("Please enter the radius of the cone: ");
			radius = input.nextDouble();
			
			System.out.println("Please enter the height of the cone: ");
			height = input.nextDouble();
			
			Cone coneObject = new Cone(radius,height);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(coneObject);
			System.out.println("The cone has been added to the list with the following dimensions");
			System.out.println(coneObject.toString()); 
		}

		else if (chosenShape.equals("cube")) 
		{
			double edge;
			
			System.out.println("Please enter the length of one edge of the cube: ");
			edge = input.nextDouble();
			
			Cube cubeObject = new Cube(edge);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(cubeObject);
			System.out.println("The cube has been added to the list with the following dimensions");
			System.out.println(cubeObject.toString()); 
		}

		else if (chosenShape.equals("prism")) 
		{
			double heightSide;
			double base;
			double prismHeight;
			double hypotenuse;
			
			System.out.println("Please enter the hypotense of the bottom triangle of the prism: ");
			hypotenuse = input.nextDouble();
			
			System.out.println("Please enter the base of the bottom triangle of the prism: ");
			base = input.nextDouble();
			
			System.out.println("Please enter the length of the third side of the bottom triangle of the prism: ");
			heightSide = input.nextDouble();
			
			System.out.println("Please enter the height of the prism: ");
			prismHeight = input.nextDouble();
			
			Prism prismObject = new Prism(heightSide, base, prismHeight, hypotenuse);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(prismObject);
			System.out.println("The prism has been added to the list with the following dimensions");
			System.out.println(prismObject.toString()); 
		}
		
		else if (chosenShape.equals("square pyramid")) 
		{
			double squareBaseLength;
			double pyramidHeight;
			
			System.out.println("Please enter the length of one side of the base of the right square pyramid: ");
			squareBaseLength = input.nextDouble();
			
			System.out.println("Please enter the height of the right square pyramid: ");
			pyramidHeight = input.nextDouble();
			
			SquarePyramid squarePyramidObject = new SquarePyramid(pyramidHeight, squareBaseLength);
			//--------------------------------------------------------------------------------------------------------------
			// Creating a new circle object and storing the area and perimeter
			shapeList.add(squarePyramidObject);
			System.out.println("The right square pyramid has been added to the list with the following dimensions");
			System.out.println(squarePyramidObject.toString()); 
		}
		
		else {System.out.println("Please make a valid choice.");}
		 
	}

	public String getShape()
	{
		String shape = "";
		return shape;
	}
}
