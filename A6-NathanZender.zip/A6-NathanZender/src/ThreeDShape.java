
// This is the superclass to all 3d shape classes

public class ThreeDShape extends Shape
{
	protected double area;
	protected double volume;
	protected String shape;
	
	public void setVolume(double volume) 
	{
		this.volume = volume;
	}
	
	public void setArea(double area) 
	{
		this.area = area;
	}
	
	public double getArea() 
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}
	
	public String getShape()
	{
		return shape;
	}
	
	@Override
	public String toString() 
	{		
		String outputSurfaceArea = "";
		String outputVolume = "";
		outputVolume = String.format("Volume = %.2f", volume);
		outputSurfaceArea = String.format("Surface Area = %.2f", area);
		return outputSurfaceArea + "\n" + outputVolume;
	}

}
