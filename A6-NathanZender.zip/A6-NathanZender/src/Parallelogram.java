
public class Parallelogram extends TwoDShape
{
	protected double base;
	protected double height;
	protected double side;
	private String shape;

	public Parallelogram(double base, double height, double side)
	{
		this.base = base;
		this.height = height;
		this.side = side;
		super.setPerimeter(2d * (base + height));
		super.setArea(base * height);
		shape = "parallelogram";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getPerimeter()
	{
		return perimeter;
	}
	
	public double getArea()
	{
		return area;
	}
	
}