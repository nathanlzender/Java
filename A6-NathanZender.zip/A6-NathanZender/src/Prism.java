
public class Prism extends ThreeDShape
{
	protected double heightSide;
	protected double base;
	protected double prismHeight;
	protected double hypotenuse;
	private String shape;

	public Prism(double heightSide, double base, double prismHeight, double hypotenuse)
	{
		this.heightSide = heightSide;
		this.base = base;
		this.prismHeight = prismHeight;
		this.hypotenuse = hypotenuse;
		
		super.setVolume(prismHeight * (.5d * (base * heightSide)));
		super.setArea((2d * (.5d * (heightSide * base))) + (prismHeight * (heightSide + base + hypotenuse)));
		shape = "prism";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getArea()
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}

}