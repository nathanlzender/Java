
public class SquarePyramid extends ThreeDShape
{
	protected double pyramidHeight;
	protected double squareBaseLength;
	private String shape;

	public SquarePyramid(double pyramidHeight, double squareBaseLength)
	{
		this.pyramidHeight = pyramidHeight;
		this.squareBaseLength = squareBaseLength;
		
		super.setVolume((1d / 3d) * Math.pow(squareBaseLength, 2) * pyramidHeight);
		super.setArea(Math.pow(squareBaseLength, 2) + 2d * squareBaseLength * (Math.sqrt(((Math.pow(squareBaseLength, 2) / 4)) + Math.pow(pyramidHeight, 2))));
		shape = "square pyramid";
	}
	
	public String getShape()
	{
		return shape;
	}
	
	public double getArea()
	{
		return area;
	}
	
	public double getvolume() 
	{
		return volume;
	}

}