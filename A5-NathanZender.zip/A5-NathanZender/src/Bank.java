/**
 * Assignment 5: This class drives the program, asking for initial input values balance and account number amount 
 * Issues: N/A
 * @author Nathan Zender
 * @version 1.0
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Bank {
	private static final double INTEREST_RATE = .02;
	ArrayList<Savings> savingsList = new ArrayList<Savings>();
	ArrayList<Checking> checkingList = new ArrayList<Checking>();
	

		public static void main(String[] args) 
		{
			Scanner input = new Scanner (System.in);
			//--------------------------------------------------------------------------------------------------------------
			// initializing variables and objects
			
			int firstChoice = 6;
			int len = 0;
			int accountNumber = 0;
			int accountIndex = 0; 
			double deposit;
			double withdraw;
			final double INTEREST_PERIOD = 2;
			Savings savingsObject = new Savings(0,0);
			Checking checkingObject = new Checking(0,0);
			Bank bankObject = new Bank();
			//--------------------------------------------------------------------------------------------------------------
			// initializing variables end
		
			System.out.println("How many accounts would you like to create?");
			len = input.nextInt();
			bankObject.initSavingsList(len);
			
			while (firstChoice != 0)
			{
				System.out.println("====================");
				System.out.println("Enter 1 to enter account amount, 2 to check an individual account, 3 to display all accounts information, 4 to display all Savings accounts, 5 to display all Checking accounts, 6 to add a new account, 7 to remove an account, or 8 to exit : ");
				firstChoice = input.nextInt();
				System.out.println("====================");
			
				if (firstChoice == 1)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option auto-generates accounts
				
					System.out.println("How many accounts would you like to create?");
					len = input.nextInt();
					bankObject.initSavingsList(len);
				}
			
				else if (firstChoice == 2)
				{
					int secondChoice = 5;
					while (secondChoice != 3) 
					{
						//--------------------------------------------------------------------------------------------------------------
						// This option allows the user to check a single account and perform deposits or withdraws
						int errorCheck = 3;	
						accountIndex = 0; 
						
						while (errorCheck != 1) 
						{
							secondChoice = 5;
							System.out.println("Enter the account number that you would like to access: ");
							accountNumber = input.nextInt();
							accountIndex = 0; 
						
							//--------------------------------------------------------------------------------------------------------------
							//getting the index value of the account in the array list
							if (accountNumber % 2 == 0) 
							{
								for (int x = 0; x < bankObject.savingsList.size(); x++) 
								{
									if (bankObject.savingsList.get(x).getAccountNumber() == accountNumber) 
									{			
										accountIndex = x;
										errorCheck = 1;
									}
									
								}
							}
							else
							{
								for (int x = 0; x < bankObject.checkingList.size(); x++) 
								{
									if (bankObject.checkingList.get(x).getAccountNumber() == accountNumber) 
									{			
										accountIndex = x;
										errorCheck = 1;
									}
									
								}
							}
							if (errorCheck != 1) {System.out.println("The account #: " + accountNumber + " doesnt exist");}
						}		
						
						//--------------------------------------------------------------------------------------------------------------
						//displaying current balance of account
							
						if (accountNumber % 2 == 0) 
						{
						
							savingsObject.setInterestRate(INTEREST_RATE);	
							System.out.println(bankObject.savingsList.get(accountIndex));																						
								
						}
							
						else 
						{								
							savingsObject.setInterestRate(INTEREST_RATE);	
							System.out.println(bankObject.checkingList.get(accountIndex));																															
						}
																			
						while ((secondChoice != 1) & (secondChoice != 2) & (secondChoice != 3))
						{
							System.out.println("Enter 1 to deposit, 2 to withdraw from this account, or 3 to exit to main menu: ");
							secondChoice = input.nextInt();
							if ((secondChoice != 1) & (secondChoice != 2) & (secondChoice != 3)) {System.out.println("Please choose one of the valid options");}
							
						}
					
						
						
						//--------------------------------------------------------------------------------------------------------------
						//If user enters a "1" then they will be moved to the deposit option
						
						if (secondChoice == 1) 
						{
							System.out.println("How much would you like to deposit?");							
							deposit = input.nextDouble();
							if (accountNumber % 2 == 0) 
							{									
								bankObject.savingsList.get(accountIndex).deposit(deposit);
								bankObject.savingsList.set(accountIndex, bankObject.savingsList.get(accountIndex));
								System.out.println("Account #" + bankObject.savingsList.get(accountIndex).getAccountNumber() + " has a new balance of: " + bankObject.savingsList.get(accountIndex).getAccountBalance());
																			
							}
							
							else 
							{
														
								bankObject.checkingList.get(accountIndex).deposit(deposit);
								bankObject.checkingList.set(accountIndex, bankObject.checkingList.get(accountIndex));		
								System.out.println("Account #" + bankObject.checkingList.get(accountIndex).getAccountNumber() + " has a new balance of: " + bankObject.checkingList.get(accountIndex).getAccountBalance());

							}
						}
						
						//--------------------------------------------------------------------------------------------------------------
						//If user enters a "2" then they will be moved to the withdraw option
						
						else if (secondChoice == 2) 
						{
							System.out.println("How much would you like to withdraw?");													
							withdraw = input.nextDouble();
							if (accountNumber % 2 == 0) 
							{
								
								bankObject.savingsList.get(accountIndex).withdraw(withdraw);
								bankObject.savingsList.set(accountIndex, bankObject.savingsList.get(accountIndex));
								System.out.println("Account #" + bankObject.savingsList.get(accountIndex).getAccountNumber() + " has a new balance of: " + bankObject.savingsList.get(accountIndex).getAccountBalance());
																													
							}
							
							else 
							{								
								bankObject.checkingList.get(accountIndex).withdraw(withdraw);
								bankObject.checkingList.set(accountIndex, bankObject.checkingList.get(accountIndex));
								System.out.println("Account #" + bankObject.checkingList.get(accountIndex).getAccountNumber() + " has a new balance of: " + bankObject.checkingList.get(accountIndex).getAccountBalance());
						
							}
							
							secondChoice = 5;
						}
						
						else {secondChoice = 3;}
					}
					
				}
			
				else if (firstChoice == 3)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option displays all account information
				
					for (int x = 0; x < bankObject.savingsList.size(); x++) 
					{
						System.out.println(bankObject.savingsList.get(x));
						System.out.println("Interest over: " + INTEREST_PERIOD + " years: " + String.format("%.2f",bankObject.savingsList.get(x).computeInterest(INTEREST_PERIOD)) + "$");
						System.out.println("====================");
					}
					
					for (int x = 0; x < bankObject.checkingList.size(); x++) 
					{
						
						System.out.println(bankObject.checkingList.get(x));
						System.out.println("Interest over: " + INTEREST_PERIOD + " years: " + String.format("%.2f",bankObject.checkingList.get(x).computeInterest(INTEREST_PERIOD)) + "$");
						System.out.println("====================");
					}
					
				}
			
				else if (firstChoice == 4)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option displays all Savings account information
				
					for (int x = 0; x < bankObject.savingsList.size(); x++) 
					{
						System.out.println(bankObject.savingsList.get(x));
						System.out.println("Interest over: " + INTEREST_PERIOD + " years: " + String.format("%.2f",bankObject.savingsList.get(x).computeInterest(INTEREST_PERIOD)) + "$");
						System.out.println("====================");
					}
				}
			
				else if (firstChoice == 5)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option displays all Checking account information
				
					for (int x = 0; x < bankObject.checkingList.size(); x++) 
					{
						
						System.out.println(bankObject.checkingList.get(x));
						System.out.println("Interest over: " + INTEREST_PERIOD + " years: " + String.format("%.2f",bankObject.checkingList.get(x).computeInterest(INTEREST_PERIOD)) + "$");
						System.out.println("====================");
					}
				}
			
				else if (firstChoice == 6)
				{
					int errorCheck2 = 5;
					//--------------------------------------------------------------------------------------------------------------
					// This option allows the user to add a new account
					while (errorCheck2 != 3) 
					{
						System.out.println("Please enter the account number you would like to add: ");
						accountNumber = input.nextInt();
						int breakWhile = 0;
						
						if (accountNumber % 2 == 0) 
						{
							breakWhile = 0;
							for (int x = 0; x < bankObject.savingsList.size(); x++) 
							{
								if (bankObject.savingsList.get(x).getAccountNumber() == accountNumber) 
								{			
									breakWhile = breakWhile + 1;
									System.out.println("Please enter an account number that is not already being used");
								}
								
								if (breakWhile != 1) {errorCheck2 = 3;}	
								
							}
						}
						
						else
						{
							breakWhile = 0;
							for (int x = 0; x < bankObject.checkingList.size(); x++) 
							{
								if (bankObject.checkingList.get(x).getAccountNumber() == accountNumber) 
								{			
									breakWhile = breakWhile + 1;
									errorCheck2 = 5;
									System.out.println("Please enter an account number that isnt already being used");									
								}
								
								if (breakWhile != 1) {errorCheck2 = 3;}
							}
						}
					}
					
					double balance;
					if (accountNumber % 2 == 0)
					{
						System.out.println("Please enter the balance of the account: ");
						//--------------------------------------------------------------------------------------------------------------
						// Creating a new savings object storing the account number and balance
						balance = input.nextDouble();
						savingsObject = new Savings(accountNumber,balance);
						savingsObject.setAccountBalance(balance);
						savingsObject.setInterestRate(INTEREST_RATE);
						
						//--------------------------------------------------------------------------------------------------------------
						// Adding account to the savings array
						bankObject.savingsList.add(savingsObject);
						
					}
					
					else 
					{
						System.out.println("Please enter the balance of the account: ");
						//--------------------------------------------------------------------------------------------------------------
						// Creating a new checking object storing the account number and balance
						balance = input.nextDouble();
						checkingObject = new Checking(accountNumber,balance);
						
						//--------------------------------------------------------------------------------------------------------------
						// Adding account to the checking array
						bankObject.checkingList.add(checkingObject);
					}
					
				}
			
				else if (firstChoice == 7)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option allows the user to remove an account
					
					System.out.println("Please enter the account number you would like to remove: ");
					accountNumber = input.nextInt();
					int errorCheck = 3;
					
					if (accountNumber % 2 == 0)
					{
						for (int x = 0; x < bankObject.savingsList.size(); x++) 
						{
							if (bankObject.savingsList.get(x).getAccountNumber() == accountNumber) 
							{
								bankObject.savingsList.remove(x);
								errorCheck = 1;
								
							}						
						}
						if (errorCheck == 1) {System.out.println("The account #: " + accountNumber + " has been removed");}
						else {System.out.println("The account #: " + accountNumber + " doesnt exist");}
							
					}
					
					else 
					{
						for (int x = 0; x < bankObject.checkingList.size(); x++) 
						{
							if (bankObject.checkingList.get(x).getAccountNumber() == accountNumber) 
							{
								bankObject.checkingList.remove(x);
								errorCheck = 1;
								
							}						
						}
						if (errorCheck == 1) {System.out.println("The account #: " + accountNumber + " has been removed");}
						else {System.out.println("The account #: " + accountNumber + " doesnt exist");}
					}
				}
					
					
				//--------------------------------------------------------------------------------------------------------------
				// Option to exit program
			
				else if (firstChoice == 8)
				{
					System.out.println("");
					System.out.println("Exiting program");
					input.close();
					System.exit(0);
				}
			
				//--------------------------------------------------------------------------------------------------------------
				// Error catching for random input choice
			
				else if ((firstChoice != 1) & (firstChoice != 2) & (firstChoice != 3) & (firstChoice != 4) & (firstChoice != 5) & (firstChoice != 6) & (firstChoice != 7) & (firstChoice != 8))
				{
					System.out.println("Use option 1 to enter an amount of accounts first or select a valid option");
					System.out.println("====================");
					System.out.println("");
				}
			}
		}
		
		
		public void initSavingsList(int n) 
		{
			savingsList.clear();
			checkingList.clear();
			double y = 50;
			int x = 101;
			int z;
		
			for (x = 0; x <= n; x++) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Calculating balance based off number of accounts
				z = 101 + x;	
				y = z * 50;
				
				//--------------------------------------------------------------------------------------------------------------
				//Checking if even or odd account number
				
				if (z % 2 == 0)
				{
					//--------------------------------------------------------------------------------------------------------------
					// Creating a new savings object storing the account number and balance
					Savings savingsObject = new Savings(z,y);
					savingsObject.setAccountBalance(y);
					savingsObject.setInterestRate(INTEREST_RATE);
					
					//--------------------------------------------------------------------------------------------------------------
					// Adding account to the savings array
					savingsList.add(savingsObject);
					
					
				}
				
				else 
				{
					//--------------------------------------------------------------------------------------------------------------
					// Creating a new checking object storing the account number and balance
					Checking checkingObject = new Checking(z,y);
					
					//--------------------------------------------------------------------------------------------------------------
					// Adding account to the checking array
					checkingList.add(checkingObject);
					
				}
				
				
			}
		}
}
