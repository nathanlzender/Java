
public class Checking extends Account 
{
	final double INTEREST_RATE = .05;
	
	//--------------------------------------------------------------------------------------------------------------
	//Constructor
			
	Checking(int accountNumberInstance, double accountBalanceInstance) 

	{
		super(accountNumberInstance);
		accountBalance = accountBalanceInstance;
		accountType = "c";
				
	}
	
	//--------------------------------------------------------------------------------------------------------------
	//Override methods
		
	@Override
	public double computeInterest(double interestPeriod)
	{
		double interest = INTEREST_RATE * interestPeriod *accountBalance ;
		return interest;
	}
	
	public String toString() 
	{
		return "Checking Account # = " + accountNumber + "\n" + "Checking Balance = " + accountBalance;
	}
	
}
