/**
 * Assignment 2: This class reads instance variables and used instance methods
 * Issues: N/A
 * @author NathanZender
 * @version 1.0
 */



import java.util.Scanner;
public class BankAccount 
{
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable declaration
	 
	private float Interest;
	private float yearDuration;
	
	
	//--------------------------------------------------------------------------------------------------------------
	//Setting instance variable
	 
	public void setInterest (float n) 
	{
		Interest = n;
	}
	
	public void setyearDuration (int n) 
	{
		yearDuration = n;
	}
	
	//--------------------------------------------------------------------------------------------------------------
	//Instance method declaration
	 
	public float checkingsInterest()
	{
		Interest = Interest * yearDuration;
		return (Interest);
	}
	
	public float savingsInterest()
	{
		Interest = Interest * yearDuration;
		return (Interest);
	}

	public static void main(String[] args)
	
	{
		//--------------------------------------------------------------------------------------------------------------
		// initializing variables
		 
		Scanner input = new Scanner (System.in);
		float balanceCheckings = 0;
		float interestrateCheckings = 0;
		int yeardurationCheckings = 0;
		float interestCheckings = 0;
		float endYearbalanceCheckings = 0;
		
		float balanceSavings = 0;
		float interestrateSavings = 0;
		int yeardurationSavings = 0;
		float interestSavings = 0;
		float endYearbalanceSavings = 0;
		
		//--------------------------------------------------------------------------------------------------------------
		// Asking input for checking's account: Beginning balance, interest rate, and year amount
		 
		
		System.out.println("What is the starting balance for the checking account?");
		balanceCheckings = input.nextFloat();
		
		System.out.println("What is the interest rate(in percent)?");
		interestrateCheckings = input.nextFloat();
		interestrateCheckings = (float) (interestrateCheckings * .01);

		System.out.println("How many years do you want to calculate for?");
		yeardurationCheckings = input.nextInt();
		
		//--------------------------------------------------------------------------------------------------------------
		//Creating checking and savings calculator objects
		
		BankAccount checkingscalculator = new BankAccount();
		BankAccount savingscalculator = new BankAccount();
		
		//--------------------------------------------------------------------------------------------------------------
		//Calculating the pre-total interest of the checkings account
		 
		interestCheckings = (balanceCheckings * interestrateCheckings);
		
		//--------------------------------------------------------------------------------------------------------------
		//Setting the instance variable value to the class variable value for the checking's account
		 
		
		checkingscalculator.setInterest(interestCheckings);
		checkingscalculator.setyearDuration(yeardurationCheckings);
		
		//--------------------------------------------------------------------------------------------------------------
		//Adding the interest to the original balance
		 
		interestCheckings = checkingscalculator.checkingsInterest();
		endYearbalanceCheckings = balanceCheckings + interestCheckings;
		
		//--------------------------------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------
		// Asking input for saving's account: Beginning balance, interest rate, and year amount
		 
		System.out.println("What is the starting balance for the saving account?");
		balanceSavings = input.nextFloat();
		
		System.out.println("What is the interest rate(in percent)?");
		interestrateSavings = input.nextFloat();
		interestrateSavings = (float) (interestrateSavings * .01);

		System.out.println("How many years do you want to calculate for?");
		yeardurationSavings = input.nextInt();
		
		//--------------------------------------------------------------------------------------------------------------
		//Calculating the pre-total interest of the savings account
		 
		
		interestSavings = (balanceSavings * interestrateSavings);
				
		//--------------------------------------------------------------------------------------------------------------
		//Setting the instance variable value to the class variable value for the checking's account
				 
				
		savingscalculator.setInterest(interestSavings);
		savingscalculator.setyearDuration(yeardurationSavings);
				
		//--------------------------------------------------------------------------------------------------------------
		//Adding the interest to the original balance
				 
		interestSavings = savingscalculator.savingsInterest();
		endYearbalanceSavings = balanceSavings + interestSavings;
		 
		
		//--------------------------------------------------------------------------------------------------------------
		// Final bank statement output
		 
		System.out.println("-------------------------");
		System.out.println("Huntington Bank Statment");
		System.out.println("-------------------------");
		System.out.println("");
		System.out.println("Checkings Acount:"); 
		System.out.println("Beginning Balance: " + balanceCheckings + "$");
		System.out.println("Interest at " + (interestrateCheckings * 100) + "%" + " for " + yeardurationCheckings + " years is: " + String.format("%.2f",interestCheckings) + "$");
		System.out.println("The total balance of your checkings account after " + yeardurationCheckings + " years will be " + String.format("%.2f",endYearbalanceCheckings ) );
		System.out.println("");
		System.out.println("Savings Acount:"); 
		System.out.println("Beginning Balance: " + balanceSavings + "$");
		System.out.println("Interest at " + (interestrateSavings * 100) + "%" + " for " + yeardurationSavings + " years is: " + String.format("%.2f",interestSavings) + "$");
		System.out.println("The total balance of your checkings account after " + yeardurationSavings + " years will be " + String.format("%.2f",endYearbalanceSavings));
		
		
		input.close();
		
	}

}

