
/**
 * Assignment 4: This is the savings account class and supplies the methods to be called from the main class
 * Issues: N/A
 * @author NathanZender
 * @version 2.0
 */



public class Saving 
{
	
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable declaration
	
	private double accountBalance;
	private int accountNumber;
	private final double INTEREST_RATE = 1.015;
	
	//--------------------------------------------------------------------------------------------------------------
	//Constructors
	
	Saving(int accountNumberInstance,double accountBalanceInstance) 

	{
	
		accountBalance = accountBalanceInstance;
		accountNumber = accountNumberInstance;
		
	}
	
	//--------------------------------------------------------------------------------------------------------------
	//Setters
			 
	public void setAccountBalance(double n) 
	{
		accountBalance = n;
	}
			
	public void setAccountNumber(int n) 
	{
		accountNumber = n;
	}
			
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable getters
			
	public double getAccountBalance() 
	{
		return accountBalance;
	}
			
	public int getAccountNumber() 
	{
		return accountNumber;
	}

	//--------------------------------------------------------------------------------------------------------------
	//Methods
			
	public double calculateInterest(double interestPeriod)
	{
		double interest = 0;
		interest = (Math.pow(INTEREST_RATE, interestPeriod) * getAccountBalance()) - getAccountBalance() ;
		return interest;
	}

	public void deposit(double depositAmount) 
	{
		
		accountBalance = accountBalance + depositAmount;
		setAccountBalance(accountBalance);
		
	}
	
	public void withdraw(double withdrawAmount) 
	{
		accountBalance = accountBalance - withdrawAmount;
		setAccountBalance(accountBalance);
	
	}
	
	public void displayAccount()
	{
			System.out.println("The savings account with account number: " + getAccountNumber() + " has a balance of: " + String.format("%.2f",(getAccountBalance())));
	}
	
}
