import java.util.ArrayList;
import java.util.Scanner;

/**
 * Assignment 4: This class drives the program, asking for initial input values balance and account number amount 
 * Issues: N/A
 * @author NathanZender
 * @version 2.0
 */

public class Bank 
{
	ArrayList<Saving> savingList = new ArrayList<Saving>();
	
	public static void main(String[] args) 
	{
		Scanner input = new Scanner (System.in);
		//--------------------------------------------------------------------------------------------------------------
		// initializing variables
		
		int firstChoice = 6;
		int len = 0;
		int accountNumber = 0;
		double interestPeriod;
		Bank bankObject = new Bank();
		Saving savingsObject = new Saving(0,0);
		
		//--------------------------------------------------------------------------------------------------------------
		// initializing variables end
		
		while (firstChoice != 0)
		{
			System.out.println("====================");
			System.out.println("Enter 1 to enter account amount, 2 to make a deposit, 3 to make a withdraw, 4 to display all accounts information, or 5 to exit : ");
			firstChoice = input.nextInt();
			System.out.println("====================");
			//--------------------------------------------------------------------------------------------------------------
			// First input for amount of accounts
			
			if (firstChoice == 1)
			{
				System.out.println("How many accounts would you like to create?");
				len = input.nextInt();
				bankObject.initSavingsList(len);
			}
			
			//--------------------------------------------------------------------------------------------------------------
			// Option to input a deposit
			
			else if (firstChoice == 2)
			{
				
				System.out.println("Please enter the account number to start a deposit: ");
				accountNumber = input.nextInt();
				int accountIndex = 0; 
				
				
				//--------------------------------------------------------------------------------------------------------------
				//getting the index value of the account in the array list
				
				accountIndex = bankObject.findSavings(accountNumber);
				
				//--------------------------------------------------------------------------------------------------------------
				//displaying current balance of account
				
				bankObject.savingList.get(accountIndex).displayAccount();
				
				System.out.println("How much do you want to deposit: ");
				double deposit = input.nextDouble();
				
				//--------------------------------------------------------------------------------------------------------------
				//Importing current values of array to constructor
				savingsObject = new Saving(accountNumber,bankObject.savingList.get(accountIndex).getAccountBalance());
				
				//--------------------------------------------------------------------------------------------------------------
				// Calling the deposit method
				
				savingsObject.deposit(deposit);
				System.out.println("For account number: " + accountNumber + " the new balance is: " + String.format("%.2f",(savingsObject.getAccountBalance())));
				bankObject.savingList.set(accountIndex,savingsObject);
				
			}
			
			//--------------------------------------------------------------------------------------------------------------
			// Option to input a withdraw
			
			else if (firstChoice == 3)
			{
				
				System.out.println("Please enter the account number to start a withdraw: ");
				accountNumber = input.nextInt();
				int accountIndex = 0; 
				
				//--------------------------------------------------------------------------------------------------------------
				//getting the index value of the account in the array list
				accountIndex = bankObject.findSavings(accountNumber);
				
				//--------------------------------------------------------------------------------------------------------------
				//Displaying current balance of account
				
				bankObject.savingList.get(accountIndex).displayAccount();
			
				System.out.println("How much you do want to withdraw: ");
				double withdraw = input.nextDouble();
				
				//--------------------------------------------------------------------------------------------------------------
				//Importing current values of array to constructor
				savingsObject = new Saving(accountNumber,bankObject.savingList.get(accountIndex).getAccountBalance());
				
				//--------------------------------------------------------------------------------------------------------------
				// Calling the withdraw method
				
				savingsObject.withdraw(withdraw);
				System.out.println("For account number: " + accountNumber + " the new balance is: " + String.format("%.2f",(savingsObject.getAccountBalance())));
				bankObject.savingList.set(accountIndex,savingsObject);
			
			}
			
			//--------------------------------------------------------------------------------------------------------------
			// Option to display all account values
			
			else if (firstChoice == 4) 
			{
				bankObject.displayAllAccounts(len);
			}
			
			//--------------------------------------------------------------------------------------------------------------
			// Option to exit program
			
			else if (firstChoice == 5)
			{
				System.out.println("");
				System.out.println("Exiting program");
				input.close();
				System.exit(0);
			}
			
			//--------------------------------------------------------------------------------------------------------------
			// Error catching for random input choice
			
			else if ((firstChoice != 1) & (firstChoice != 2) & (firstChoice != 3) & (firstChoice != 4) & (firstChoice != 5))
			{
				System.out.println("Use option 1 to enter an amount of accounts first or select a valid option");
				System.out.println("====================");
				System.out.println("");
			}
		}
	}
		
	
		//--------------------------------------------------------------------------------------------------------------
		//Methods
	
	public void initSavingsList(int n) 
		{
			int y = 500;
			int x = 101;
			int z;
			Saving savingsObject = new Saving(x,y);
		
			for (x = 0; x <= n; x++) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Calculating balance based off number of accounts
				z = 101 + x;	
				y = x * 500;
				savingsObject = new Saving(z,y);
				
				//--------------------------------------------------------------------------------------------------------------
				// Adding info to Array List
				savingList.add(savingsObject);
				
			}
		}
		
	void displayAllAccounts(int len) 
	{
		int accountIndex;
		//--------------------------------------------------------------------------------------------------------------
		// Calling displayAccount method to display output
		for (int x = 0; x < savingList.size(); x++) 
		{
			accountIndex = findSavings((x + 101));
			savingList.get(accountIndex).displayAccount();
		}
	}
		
	public int findSavings(int accountNumber) 
	{
		
		int z = 0;
		int y = -1;
		for(int x = 0;((y != accountNumber) & (x < savingList.size()));x++) 
		{
			// gets account number from array
			y = savingList.get(x).getAccountNumber();
			
			// sets z to index of account number
			z = x;
			
			
		}
		
		return z;
	}
		
	public static void addSavingsAccount() 
	{
			
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Methods end
	
}


